# Emotiv SDK - Advanced Edition

The Emotiv SDK Advanced Edition includes all the functionality of the Community Edition, plus Performance Metrics and/or EEG data access API, depending on the license type.

This repo only contains examples and API documents for the SDK.

If you are interested in the Advanced SDK, please contact hello@emotiv.com for further details.
